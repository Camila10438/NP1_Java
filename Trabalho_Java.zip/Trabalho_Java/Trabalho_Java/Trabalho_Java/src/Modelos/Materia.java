package Modelos;

public class Materia {
	
	// ini de variáveis
	private String nome;
	private int ano;
	
	// constructor
	public Materia(String nome, int ano){
		this.nome = nome;
		this.ano = ano;
	}
	
	// getters e setters
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	
	
}
