package Modelos;

public class Notas {
	
	// ini de variáveis
	private double np1;
	private double np2;
	private double sub;
	private double exame;
	private boolean aprovado;
	private double media;
	
	//constructor
	public Notas(double np1, double np2, double sub, double exame){
		
		//recebe as variáveis
		this.np1 = np1;
		this.np2 = np2;
		this.sub = sub;
		this.exame = exame;
		
		// calcula a média
		double mini = Math.min(Math.min(np1, np2), sub);
		if(mini == np1) {
			np1 = 0;
		}else if(mini == np2) {
			np2 = 0;
		}else if (mini == sub) {
			sub = 0;
		}
		double med = (np1+np2+sub)/2;
		
		// verifica e faz o calculo do exame
		if(med < 7) {
			med = (med + exame)/2;
		}
		this.setMedia(med);
		
		// verifica se está aprovado
		if (med < 5) {
			this.setAprovado(false);
		} else {
			this.setAprovado(true);
		}
	}
	
	
	// getters e setters
	public double getNp1() {
		return np1;
	}
	public void setNp1(double np1) {
		this.np1 = np1;
	}
	public double getNp2() {
		return np2;
	}
	public void setNp2(double np2) {
		this.np2 = np2;
	}
	public double getSub() {
		return sub;
	}
	public void setSub(double sub) {
		this.sub = sub;
	}
	public double getExame() {
		return exame;
	}
	public void setExame(double exame) {
		this.exame = exame;
	}
	public boolean isAprovado() {
		return aprovado;
	}
	public void setAprovado(boolean aprovado) {
		this.aprovado = aprovado;
	}
	public double getMedia() {
		return media;
	}
	public void setMedia(double media) {
		this.media = media;
	}
	
	
}
