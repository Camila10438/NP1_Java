package principal;

import Modelos.Materia;
import Modelos.Repeticao;
import Modelos.Notas;
import Modelos.Rendimento;
import java.io.IOException;
import java.util.Scanner;

public class Teste {

	public static void main(String[] args) {

		Cadastro cadastro = new Cadastro();

		cadastro.addRendimento(new Rendimento(new Materia("APOO", 2020),  new Notas(7, 8, 0, 0)));
		cadastro.addRendimento(new Rendimento(new Materia("BPOO", 2020),  new Notas(2, 2, 6, 10)));
		cadastro.addRendimento(new Rendimento(new Materia("CPOO", 2021),  new Notas(2, 8, 8, 0)));
		cadastro.addRendimento(new Rendimento(new Materia("DPOO", 2021),  new Notas(0, 1, 2, 3)));
		
	    Scanner sc = new Scanner(System.in);
	    
            jumpScreen();
	    System.out.println("Bem vindo ao sistema de controle de matérias e notas!");
	    
	    boolean ok = false;
	    while (ok == false) {
		    System.out.println("escolha alguma das funções abaixo disponíveis...\n"
		    				+  "\n1. Cadastrar uma nova matéria e suas notas."
		    				+  "\n2. Listar todas as matérias cadastradas."
		    				+  "\n3. Listar todas as matérias de um ano específico."
		    				+  "\n4. Listar todas as matérias aprovadas/reprovadas."
		    				+  "\n5. Exibir um relatório das matérias."
		    				+  "\n6. Sair"
		    				+  "\n\nDigite aqui o numero que corresponde a uma opção:");
		    try {
		    	int in = sc.nextInt();
		    	if (in == 1) {
		    		
		    		jumpScreen();
		
		    		System.out.println("\nMuito bem, vamos lá.");
	    			System.out.println("Digite aqui o nome da nova máteria a ser cadastrada:");
		    		String n = sc.nextLine();
		    		n = sc.nextLine();
		    		System.out.println("\nAgora digite o ano dessa matéria:");
					int y = sc.nextInt();
		    		System.out.println("\nAgora a nota da np1 do aluno:");
					double n1 = sc.nextDouble();
		    		System.out.println("\nAgora a nota da np2:");
					double n2 = sc.nextDouble();
		    		System.out.println("\nAgora a nota da sub:");
					double sb = sc.nextDouble();
		    		System.out.println("\nAgora a nota do exame:");
					double ex = sc.nextDouble();
					
					cadastro.addRendimento(new Rendimento(new Materia(n, y),  new Notas(n1, n2, sb, ex)));

					System.out.println("\nA matéria " + n.trim() + " foi cadastrada com sucesso!");
					
		    	} else if (in == 2) {
		    		
		    		jumpScreen();

					System.out.println("\nAqui está uma lista completa com todas as matérias já cadastradas:");
		    		cadastro.listarMaterias();
					System.out.println("\n");
		    		
		    	} else if (in == 3) {
		    		
		    		jumpScreen();

		    		System.out.println("\nPor favor digite um ano:");
					int y = sc.nextInt();
					System.out.println("\nAqui está uma lista completa com todas as matérias do ano " + String.valueOf(y) + " já cadastradas:");
		    		cadastro.imprimeMateriasDoAno(y);
					System.out.println("\n");
					
		    	} else if (in == 4) {
		    		
		    		jumpScreen();
		    		
					boolean work = false;
					while(work == false) {
			    		System.out.println("\nAgora será exibido uma lista com matérias aprovadas e reprovadas"
			    						+  "\nmas antes por favor digite 0 para Reprovadas e 1 para Aprovadas:");
						int b = sc.nextInt();
						switch (b) {
							case 0:
					    		System.out.println("\nAqui está uma lista com todas as matérias Reprovadas cadastradas:");
					    		cadastro.imprimeMateriasStatus(false);
					    		work = true;
								break;
							case 1:
								System.out.println("\nAqui está uma lista com todas as matérias Aprovadas cadastradas:");
					    		cadastro.imprimeMateriasStatus(true);
					    		work = true;
								break;
							default:
								System.out.println("Por favor escolha um numero válido!");
								break;
						}
					}
		    		
		    	} else if (in == 5) {
		    		
		    		jumpScreen();

					System.out.println("\nRelatório completo geral de todas as matérias:\n");
		    		cadastro.fazRelatorio();
					System.out.println("\n");
		    		
		    	} else if (in == 6) {
		    		
		    		ok = true;
		    		jumpScreen();
		    		System.out.println("\nObrigado por utilizar o serviço!"
		    						+  "\nFake Saving, please wait...");
		    		Thread.sleep(2000);
		    		System.out.println("\nBye :)");
		    		break;
		    	} else {
		    		throw new java.util.InputMismatchException();
		    	}
		    	System.out.println("\npressione enter para retornar ao menu inicial...");
		    	System.in.read();
	    		jumpScreen();
		    	
		    } catch (java.util.InputMismatchException e) {
	    		jumpScreen();
		    	System.out.println("Desculpe, mas essa decisão é Inválida :(");
		    	String y = sc.next();
		    } catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	    }
		
		
	    sc.close();
	}
	
	public static void jumpScreen() {  
	    System.out.print(Repeticao.repeat("\n",100));  
	    System.out.flush();  
	} 

}