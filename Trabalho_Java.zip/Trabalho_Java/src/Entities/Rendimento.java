package Entities;

public class Rendimento {
	
	// ini de variáveis
	private Materia materia;
	private Notas notas;
	
	// constructor
	public Rendimento(Materia materia,Notas notas){
		this.setMateria(materia);
		this.setNotas(notas);
	}

	// getters e setters
	public Materia materia() {
		return materia;
	}

	public void setMateria(Materia materia) {
		this.materia = materia;
	}

	public Notas notas() {
		return notas;
	}

	public void setNotas(Notas notas) {
		this.notas = notas;
	}
	
}
