package Entities;

public class Repeticao {
    
    public static String repeat(String text, Integer num){
        String res = "";
        for (int i = 0; i < num; i++) {
            res += text;
        }
        return res;
    }
}
       
