package principal;

import Entities.*;
import java.util.ArrayList;
import java.util.List;

public class Cadastro {
	
	// ini de variáveis
	private List<Rendimento> rendimento = new ArrayList<Rendimento>();
	
	// constructor
	Cadastro(){
		
	}
	
	/***** metodos *****/
	// adiciona uma nova matéria com novas notas
	public void addRendimento(Rendimento rendimento) {
		this.rendimento.add(rendimento);
	}
	
	// lista todas as matérias existentes
	public void listarMaterias() {
		for(int i = 0; i < this.rendimento.size(); i++) {
			System.out.println(rendimento.get(i).materia().getNome());
		}
	}
	
	// lista todas as matérias de um ano específico
	public void imprimeMateriasDoAno(int ano) {
		boolean has = false;
		for(int i = 0; i < this.rendimento.size(); i++) {
			if (rendimento.get(i).materia().getAno() == ano) {
				System.out.println(rendimento.get(i).materia().getNome());
				has = true;
			}
		}
		if(has == false) {
			System.out.println("\nNão há nenhuma matéria cadastrada no ano de " + String.valueOf(ano));
		}
	}
	
	// lista todas as matérias aprovadas/reprovadas
	public void imprimeMateriasStatus(boolean aprovado) {
		boolean has = false;
		for(int i = 0; i < this.rendimento.size(); i++) {
			if (rendimento.get(i).notas().isAprovado() == aprovado) {
				System.out.println(rendimento.get(i).materia().getNome());
				has = true;
			}
		}
		if(!(has)&&(aprovado)) {
			System.out.println("\nNão há nenhuma matéria Aprovada registrada");
		} else if(!(has)&&!(aprovado)) {
			System.out.println("\nNão há nenhuma matéria Reprovada registrada");
		}
	}
	
	// faz um relatório de todas as matérias
	public void fazRelatorio() {
		
		// inicialização de variáveis
		int size = this.rendimento.size();
		String[] nomes = new String[size];
		String[] medias = new String[size];
		String[] status = new String[size];
		String[] tabela = new String[size+1];
		
		// converte nomes, medias e status para strings e deixa-os com o mesmo numero de caracteres
		int maxsizeM = "MATERIA".length();
		int maxsizeN = "MEDIA".length();
		for(int i = 0; i < size; i++) {
			String nome = this.rendimento.get(i).materia().getNome();
			if (nome.length() > maxsizeM) {
				for(int k = 0; k < i; k++) {
					nomes[k] += Repeticao.repeat(" ", nome.length()-maxsizeM);
				}
				maxsizeM = nome.length();
			} else if (nome.length() < maxsizeM) {
				nome += Repeticao.repeat(" ", maxsizeM-nome.length());
			}
			nomes[i] = nome;
			
			String media = String.valueOf(this.rendimento.get(i).notas().getMedia());
			if (media.length() > maxsizeN) {
				for(int k = 0; k < i; k++) {
					medias[k] += Repeticao.repeat(" ", media.length()-maxsizeN);
				}
				maxsizeN = media.length();
			} else if (media.length() < maxsizeN) {
				media += Repeticao.repeat(" ", maxsizeN-media.length());
			}
			medias[i] = media;
			
			if (this.rendimento.get(i).notas().isAprovado()){
				status[i] = "APROVADO ";
			} else {
				status[i] = "REPROVADO";
			}
		}
		
		// cria a tabela de nomes, medias e status
		tabela[0] = "|MATERIA" + Repeticao.repeat(" ", maxsizeM-7) + "|MEDIA" + Repeticao.repeat(" ", maxsizeN-5) + "|STATUS   |";
		for(int i = 0; i < size; i++) {
			tabela[i+1] = "|" + nomes[i] + " " + medias[i] + " " + status[i] + "|";
		}
			
		// calculo de maio e menor média
		double[] meds = new double[size];
		double mx_media = 0;
		String smx_media = "";
		double mn_media = 1000000;
		String smn_media = "";
		for(int i = 0; i < size; i++) {
			meds[i] = this.rendimento.get(i).notas().getMedia();
			if (meds[i] > mx_media) {
				mx_media = meds[i];
				smx_media = this.rendimento.get(i).materia().getNome();
			}
			if (meds[i] < mn_media) {
				mn_media = meds[i];
				smn_media = this.rendimento.get(i).materia().getNome();
			}
		}
		
		// calculo de coeficiente de rendimento
		double rend = 0;
		for(double d : meds) {
			rend += d;
		}
		rend /= meds.length;
		
		// saida final
		for(int i = 0; i < tabela.length; i++) {
			System.out.println(tabela[i]);
		}

		System.out.println("\nMatéria com maior media: " + smx_media);
		System.out.println("Media: " + String.valueOf(mx_media));
		System.out.println("\nMatéria com menor media: " + smn_media);
		System.out.println("Media: " + String.valueOf(mn_media));

		System.out.println("\nCoeficiente de rendimento: " + String.valueOf(rend));
		
		
		
		
		
	}
}
