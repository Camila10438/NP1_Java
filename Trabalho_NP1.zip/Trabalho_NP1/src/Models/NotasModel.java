package Models;

public class NotasModel {

    private double np1;
    private double np2;
    private double sub;
    private double exame;
    private boolean aprovado;
    private double media;
    
    private MateriaModel materia;

    public NotasModel(double aNp1, double aNp2, double aSub, double aExame, MateriaModel aMateria) {
        this.np1 = aNp1;
        this.np2 = aNp2;
        this.sub = aSub;
        this.exame = aExame;
        this.materia = aMateria;
    }

    public double getNp1() {
        return np1;
    }

    public void setNp1(double np1) {
        this.np1 = np1;
    }

    public double getNp2() {
        return np2;
    }

    public void setNp2(double np2) {
        this.np2 = np2;
    }

    public double getSub() {
        return sub;
    }

    public void setSub(double sub) {
        this.sub = sub;
    }

    public double getExame() {
        return exame;
    }

    public void setExame(double exame) {
        this.exame = exame;
    }
    
      public boolean isAprovado() {
        return aprovado;
    }

    public void setAprovado(boolean aprovado) {
        this.aprovado = aprovado;
    }
    
      public double getMedia() {
        return media;
    }

    public void setMedia(double media) {
        this.media = media;
    }

    private void atualizarMedia() {
        double np1 = getNp1();
        double np2 = getNp2();
        double sub = getSub();
        double exame = getExame();
        if (sub > np1 || sub > np2) {
            if (np1 > np2) {
                np2 = sub;
            } else {
                np1 = sub;
            }
        }

        double mediaInicial = (np1 + np2) / 2.0;
        if (mediaInicial >= 7.0) {
            setAprovado(true);
        } else {
            double mediaFinal = (mediaInicial + exame) / 2.0;
            if (mediaFinal >= 5.0) {
                this.setMedia(mediaFinal);
                setAprovado(true);
            } else {
                this.setMedia(mediaFinal);
                setAprovado(false);
            }
        }
    }
}
