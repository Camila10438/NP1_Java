package Models;

public class MateriaModel {
    
    private String nome;
    private int ano;
    
    public MateriaModel(String aNome, int aAno){
        this.nome = aNome;
        this.ano = aAno;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    
    
}
